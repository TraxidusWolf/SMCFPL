__version__ = 0.1
"""
    Archivo principal para ejecutar programa.
    Creado por:
        Gabriel Seguel G.
"""
# notar que la ruta de trabajo es mantenida desde el archivo que hace la llamada al módulo
from smcfpl.create_elements import *
from smcfpl.in_out_proc import *
from smcfpl.aux_funcs import *
