from smcfpl.in_out_proc.read_inputs import *
from smcfpl.in_out_proc.write_outputs import *
# print("__init__ de {} ejecutado!".format(__name__))
